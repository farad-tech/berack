<?php

namespace App\Providers\Filament;

use App\Filament\Pages\Dashboard;
use Filament\Navigation\NavigationGroup;
use Filament\Navigation\NavigationItem;
use Filament\Http\Middleware\Authenticate;
use Filament\Http\Middleware\AuthenticateSession;
use Filament\Http\Middleware\DisableBladeIconComponents;
use Filament\Http\Middleware\DispatchServingFilamentEvent;
use Filament\Panel;
use Filament\PanelProvider;
use Filament\Support\Assets\Css;
use Filament\Support\Colors\Color;
use Filament\Support\Icons\Heroicon;
use Filament\Widgets\AccountWidget;
use Illuminate\Cookie\Middleware\AddQueuedCookiesToResponse;
use Illuminate\Cookie\Middleware\EncryptCookies;
use Illuminate\Foundation\Http\Middleware\PreventRequestForgery;
use Illuminate\Routing\Middleware\SubstituteBindings;
use Illuminate\Session\Middleware\StartSession;
use Illuminate\View\Middleware\ShareErrorsFromSession;

class AppPanelProvider extends PanelProvider
{
    public function panel(Panel $panel): Panel
    {
        return $panel
            ->default()
            ->id('app')
            ->path('panel')
            ->login()
            ->registration()
            ->brandName('Berack')
            ->sidebarCollapsibleOnDesktop()
            ->sidebarWidth('18rem')
            ->font(
                family: 'Vazirmatn',
                url: url('/assets/fonts/vazirmatn.css'),
            )
            ->colors([
                'primary' => [
                    50 => '#eef8f2',
                    100 => '#d9f0e3',
                    200 => '#b6dfca',
                    300 => '#85c8aa',
                    400 => '#54aa86',
                    500 => '#348e6b',
                    600 => '#267256',
                    700 => '#205b47',
                    800 => '#1c493b',
                    900 => '#183c32',
                    950 => '#0b211b',
                ],
                'gray' => Color::Zinc,
            ])
            ->assets([
                Css::make('berack-panel')->html(asset('css/berack-panel.css')),
            ])
            ->navigationGroups([
                NavigationGroup::make(fn (): string => app()->getLocale() === 'fa' ? 'راه‌اندازی' : 'Setup'),
                NavigationGroup::make(fn (): string => app()->getLocale() === 'fa' ? 'گزارش‌ها' : 'Reports'),
                NavigationGroup::make(fn (): string => app()->getLocale() === 'fa' ? 'راهنما' : 'Help'),
            ])
            ->navigationItems([
                NavigationItem::make(fn (): string => app()->getLocale() === 'fa' ? 'راهنمای نصب' : 'Setup guide')
                    ->group(fn (): string => app()->getLocale() === 'fa' ? 'راهنما' : 'Help')
                    ->icon(Heroicon::BookOpen)
                    ->url(fn (): string => url(app()->getLocale() === 'fa' ? '/guide' : '/en/guide'), shouldOpenInNewTab: true)
                    ->sort(PHP_INT_MAX),
            ])
            ->discoverResources(in: app_path('Filament/Resources'), for: 'App\Filament\Resources')
            ->discoverPages(in: app_path('Filament/Pages'), for: 'App\Filament\Pages')
            ->pages([
                Dashboard::class,
            ])
            ->discoverWidgets(in: app_path('Filament/Widgets'), for: 'App\Filament\Widgets')
            ->widgets([
                // AccountWidget::class,
            ])
            ->middleware([
                EncryptCookies::class,
                AddQueuedCookiesToResponse::class,
                StartSession::class,
                AuthenticateSession::class,
                ShareErrorsFromSession::class,
                PreventRequestForgery::class,
                SubstituteBindings::class,
                DisableBladeIconComponents::class,
                DispatchServingFilamentEvent::class,
            ])
            ->authMiddleware([
                Authenticate::class,
            ]);
    }
}
