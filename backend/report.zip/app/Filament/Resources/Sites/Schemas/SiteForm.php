<?php

namespace App\Filament\Resources\Sites\Schemas;

use Filament\Forms\Components\Placeholder;
use Filament\Forms\Components\TextInput;
use Filament\Schemas\Components\Section;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Illuminate\Support\HtmlString;

class SiteForm
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                Section::make(static::t('سایتت را اضافه کن', 'Add your website'))
                    ->description(static::t(
                        'فقط نام سایت و دامنه را وارد کن. براک خودش API key و تگ نصب را می‌سازد.',
                        'Enter the site name and domain. Berack will generate the API key and install tag for you.',
                    ))
                    ->icon(Heroicon::BuildingStorefront)
                    ->schema([
                        TextInput::make('name')
                            ->label(static::t('نام سایت', 'Site name'))
                            ->placeholder(static::t('مثلا فروشگاه من', 'Example: My store'))
                            ->helperText(static::t('این نام فقط داخل پنل براک نمایش داده می‌شود.', 'This name is only shown inside your Berack panel.'))
                            ->required()
                            ->maxLength(255)
                            ->columnSpanFull(),
                        TextInput::make('domain')
                            ->label(static::t('دامنه سایت', 'Website domain'))
                            ->placeholder('example.com')
                            ->helperText(static::t('بدون https:// وارد کن. اگر هنوز دامنه نداری، می‌توانی بعدا ویرایشش کنی.', 'Enter it without https://. You can edit it later if you do not have a domain yet.'))
                            ->maxLength(255)
                            ->columnSpanFull(),
                        TextInput::make('api_key')
                            ->label('API key')
                            ->disabled()
                            ->dehydrated(false)
                            ->placeholder(static::t('بعد از ذخیره ساخته می‌شود', 'Generated after saving'))
                            ->helperText(static::t('بعد از ساخت سایت، کلید و کد نصب آماده کپی کردن می‌شوند.', 'After creating the website, the key and install snippet will be ready to copy.'))
                            ->columnSpanFull(),
                    ]),
                Section::make(static::t('بعدش چه می‌شود؟', 'What happens next?'))
                    ->icon(Heroicon::CodeBracketSquare)
                    ->schema([
                        Placeholder::make('setup_steps')
                            ->label('')
                            ->content(new HtmlString(static::t(
                                '<ol class="list-decimal space-y-2 ps-5"><li>روی دکمه ساخت سایت بزن.</li><li>کد نصب آماده را از صفحه بعد کپی کن.</li><li>کد را قبل از بسته شدن تگ head در سایتت قرار بده.</li><li>چند دقیقه بعد آمار بازدیدها در داشبورد نمایش داده می‌شود.</li></ol>',
                                '<ol class="list-decimal space-y-2 ps-5"><li>Create the website.</li><li>Copy the ready install snippet from the next page.</li><li>Paste it before the closing head tag on your website.</li><li>Your visits will appear in the dashboard after a few minutes.</li></ol>',
                            )))
                            ->columnSpanFull(),
                    ])
                    ->collapsible(),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
