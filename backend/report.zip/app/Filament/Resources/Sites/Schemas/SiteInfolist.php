<?php

namespace App\Filament\Resources\Sites\Schemas;

use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Schema;

class SiteInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextEntry::make('name')
                    ->label(static::t('نام سایت', 'Site name')),
                TextEntry::make('domain')
                    ->label(static::t('دامنه', 'Domain'))
                    ->placeholder('-'),
                TextEntry::make('api_key')
                    ->label('API key')
                    ->copyable(),
                TextEntry::make('sdkUrl')
                    ->label(static::t('لینک SDK', 'SDK URL'))
                    ->helperText(static::t('اگر فقط آدرس فایل SDK را لازم داری، این لینک را کپی کن.', 'Copy this URL if you only need the SDK file address.'))
                    ->state(fn ($record): string => $record->sdkUrl())
                    ->copyable()
                    ->columnSpanFull(),
                TextEntry::make('sdkSnippet')
                    ->label(static::t('کد نصب تگ', 'Install snippet'))
                    ->helperText(static::t('این کد را قبل از بسته شدن تگ head در سایتت قرار بده.', 'Paste this before the closing head tag on your website.'))
                    ->state(fn ($record): string => $record->sdkSnippet())
                    ->copyable()
                    ->columnSpanFull(),
                TextEntry::make('trackerEvents_count')
                    ->label(static::t('کل بازدیدها', 'Events'))
                    ->state(fn ($record): int => $record->trackerEvents()->count()),
                TextEntry::make('events_today')
                    ->label(static::t('بازدیدهای امروز', 'Events today'))
                    ->state(fn ($record): int => $record->trackerEvents()->whereDate('occurred_at', today())->count()),
                TextEntry::make('unique_visitors')
                    ->label(static::t('بازدیدکننده‌های یکتا', 'Unique visitors'))
                    ->state(fn ($record): int => $record->trackerEvents()->whereNotNull('anonymous_id')->distinct('anonymous_id')->count('anonymous_id')),
                TextEntry::make('sessions')
                    ->label(static::t('نشست‌ها', 'Sessions'))
                    ->state(fn ($record): int => $record->trackerEvents()->whereNotNull('session_id')->distinct('session_id')->count('session_id')),
                TextEntry::make('last_seen_at')
                    ->label(static::t('آخرین بازدید', 'Last event'))
                    ->state(fn ($record): ?string => $record->trackerEvents()->max('occurred_at'))
                    ->dateTime()
                    ->placeholder('-'),
                TextEntry::make('top_page')
                    ->label(static::t('محبوب‌ترین صفحه', 'Top page'))
                    ->state(function ($record): string {
                        $row = $record->trackerEvents()
                            ->selectRaw('path, COUNT(*) as views')
                            ->whereNotNull('path')
                            ->groupBy('path')
                            ->orderByDesc('views')
                            ->first();

                        return $row ? "{$row->path} ({$row->views})" : '-';
                    }),
                TextEntry::make('created_at')
                    ->label(static::t('تاریخ ساخت', 'Created at'))
                    ->dateTime(),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
