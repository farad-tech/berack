<?php

namespace App\Filament\Resources\Sites\Tables;

use App\Filament\Resources\Sites\SiteResource;
use Filament\Actions\Action;
use Filament\Actions\BulkActionGroup;
use Filament\Actions\CreateAction;
use Filament\Actions\DeleteBulkAction;
use Filament\Actions\EditAction;
use Filament\Actions\ViewAction;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;

class SitesTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')
                    ->label(static::t('نام سایت', 'Site name'))
                    ->searchable()
                    ->sortable(),
                TextColumn::make('domain')
                    ->label(static::t('دامنه', 'Domain'))
                    ->searchable()
                    ->placeholder('-'),
                TextColumn::make('api_key')
                    ->label('API key')
                    ->copyable()
                    ->limit(18),
                TextColumn::make('tracker_events_count')
                    ->label(static::t('کل بازدیدها', 'Events'))
                    ->counts('trackerEvents')
                    ->sortable(),
                TextColumn::make('events_today')
                    ->label(static::t('امروز', 'Today'))
                    ->state(fn ($record): int => $record->trackerEvents()->whereDate('occurred_at', today())->count())
                    ->sortable(),
                TextColumn::make('unique_visitors')
                    ->label(static::t('بازدیدکننده‌ها', 'Visitors'))
                    ->state(fn ($record): int => $record->trackerEvents()->whereNotNull('anonymous_id')->distinct('anonymous_id')->count('anonymous_id')),
                TextColumn::make('last_seen_at')
                    ->label(static::t('آخرین بازدید', 'Last event'))
                    ->state(fn ($record): ?string => $record->trackerEvents()->max('occurred_at'))
                    ->dateTime()
                    ->placeholder('-'),
                TextColumn::make('created_at')
                    ->label(static::t('تاریخ ساخت', 'Created at'))
                    ->dateTime()
                    ->sortable(),
            ])
            ->filters([
                //
            ])
            ->emptyStateIcon(Heroicon::BuildingStorefront)
            ->emptyStateHeading(static::t('اولین سایتت را اضافه کن', 'Add your first website'))
            ->emptyStateDescription(static::t(
                'بعد از ثبت سایت، براک API key و کد نصب آماده را به تو می‌دهد.',
                'After adding a website, Berack gives you the API key and ready install snippet.',
            ))
            ->emptyStateActions([
                CreateAction::make()
                    ->label(static::t('شروع راه‌اندازی', 'Start setup'))
                    ->icon(Heroicon::Plus),
            ])
            ->recordActions([
                Action::make('reports')
                    ->label(static::t('گزارش‌ها', 'Reports'))
                    ->icon(Heroicon::ChartBarSquare)
                    ->url(fn ($record): string => SiteResource::getUrl('reports', ['record' => $record])),
                ViewAction::make(),
                EditAction::make(),
            ])
            ->toolbarActions([
                BulkActionGroup::make([
                    DeleteBulkAction::make(),
                ]),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
