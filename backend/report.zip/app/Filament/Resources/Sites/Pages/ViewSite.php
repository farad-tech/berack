<?php

namespace App\Filament\Resources\Sites\Pages;

use App\Filament\Resources\Sites\SiteResource;
use Filament\Actions\Action;
use Filament\Actions\EditAction;
use Filament\Resources\Pages\ViewRecord;
use Filament\Support\Icons\Heroicon;
use Illuminate\Contracts\Support\Htmlable;

class ViewSite extends ViewRecord
{
    protected static string $resource = SiteResource::class;

    public function getTitle(): string|Htmlable
    {
        return app()->getLocale() === 'fa'
            ? 'کد نصب و تنظیمات سایت'
            : 'Install tag and website settings';
    }

    protected function getHeaderActions(): array
    {
        return [
            Action::make('reports')
                ->label(app()->getLocale() === 'fa' ? 'مشاهده گزارش‌ها' : 'View reports')
                ->icon(Heroicon::ChartBarSquare)
                ->url(fn (): string => SiteResource::getUrl('reports', ['record' => $this->getRecord()])),
            EditAction::make()
                ->label(app()->getLocale() === 'fa' ? 'ویرایش سایت' : 'Edit website'),
        ];
    }
}
