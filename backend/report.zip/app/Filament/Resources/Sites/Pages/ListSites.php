<?php

namespace App\Filament\Resources\Sites\Pages;

use App\Filament\Resources\Sites\SiteResource;
use Filament\Actions\CreateAction;
use Filament\Resources\Pages\ListRecords;
use Filament\Support\Icons\Heroicon;
use Illuminate\Contracts\Support\Htmlable;

class ListSites extends ListRecords
{
    protected static string $resource = SiteResource::class;

    public function getTitle(): string|Htmlable
    {
        return app()->getLocale() === 'fa' ? 'سایت‌های من' : 'My websites';
    }

    protected function getHeaderActions(): array
    {
        return [
            CreateAction::make()
                ->label(app()->getLocale() === 'fa' ? 'افزودن سایت' : 'Add website')
                ->icon(Heroicon::Plus),
        ];
    }
}
