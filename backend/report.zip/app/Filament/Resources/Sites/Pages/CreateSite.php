<?php

namespace App\Filament\Resources\Sites\Pages;

use App\Filament\Resources\Sites\SiteResource;
use Filament\Actions\Action;
use Filament\Resources\Pages\CreateRecord;
use Illuminate\Contracts\Support\Htmlable;

class CreateSite extends CreateRecord
{
    protected static string $resource = SiteResource::class;

    protected static bool $canCreateAnother = false;

    public function getTitle(): string|Htmlable
    {
        return app()->getLocale() === 'fa' ? 'راه‌اندازی سایت جدید' : 'Set up a new website';
    }

    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['user_id'] = auth()->id();

        return $data;
    }

    protected function getCreatedNotificationTitle(): ?string
    {
        return app()->getLocale() === 'fa'
            ? 'سایت ساخته شد. حالا کد نصب را کپی کن.'
            : 'Website created. Now copy your install snippet.';
    }

    protected function getCreateFormAction(): Action
    {
        return parent::getCreateFormAction()
            ->label(app()->getLocale() === 'fa' ? 'ساخت سایت و دریافت تگ' : 'Create website and get tag');
    }
}
