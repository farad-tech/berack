<?php

namespace App\Filament\Resources\Sites\Pages;

use App\Filament\Resources\Sites\SiteResource;
use Filament\Resources\Pages\Concerns\InteractsWithRecord;
use Filament\Resources\Pages\Page;
use Illuminate\Contracts\Support\Htmlable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Carbon;

class SiteReports extends Page
{
    use InteractsWithRecord;

    protected static string $resource = SiteResource::class;

    protected string $view = 'filament.resources.sites.pages.site-reports';

    public function mount(int | string $record): void
    {
        $this->record = $this->resolveRecord($record);

        $this->authorizeAccess();
    }

    public function hydrate(): void
    {
        $this->authorizeAccess();
    }

    public function getTitle(): string | Htmlable
    {
        return $this->t('گزارش‌های ' . $this->getRecord()->name, $this->getRecord()->name . ' reports');
    }

    public function getBreadcrumb(): string
    {
        return $this->t('گزارش‌ها', 'Reports');
    }

    /**
     * @return array<string, string|int|null>
     */
    public function getReportStats(): array
    {
        $events = $this->eventsQuery();
        $todayEvents = (clone $events)->whereDate('occurred_at', today())->count();
        $yesterdayEvents = (clone $events)->whereDate('occurred_at', today()->subDay())->count();

        return [
            'total' => (clone $events)->count(),
            'today' => $todayEvents,
            'yesterdayDelta' => $todayEvents - $yesterdayEvents,
            'visitors' => (clone $events)->whereNotNull('anonymous_id')->distinct('anonymous_id')->count('anonymous_id'),
            'sessions' => (clone $events)->whereNotNull('session_id')->distinct('session_id')->count('session_id'),
            'pages' => (clone $events)->whereNotNull('path')->distinct('path')->count('path'),
            'lastSeenAt' => (clone $events)->max('occurred_at'),
        ];
    }

    /**
     * @return array<int, array{label: string, views: int}>
     */
    public function getDailyViews(): array
    {
        $start = today()->subDays(13);

        $counts = $this->eventsQuery()
            ->whereDate('occurred_at', '>=', $start)
            ->selectRaw('DATE(occurred_at) as event_date, COUNT(*) as views')
            ->groupBy('event_date')
            ->pluck('views', 'event_date');

        $days = [];

        for ($day = $start->copy(); $day <= today(); $day->addDay()) {
            $key = $day->toDateString();

            $days[] = [
                'label' => $day->format('M j'),
                'views' => (int) ($counts[$key] ?? 0),
            ];
        }

        return $days;
    }

    /**
     * @return array<int, array{path: string, title: string|null, views: int, visitors: int}>
     */
    public function getTopPages(): array
    {
        return $this->eventsQuery()
            ->selectRaw('path, MAX(title) as title, COUNT(*) as views, COUNT(DISTINCT anonymous_id) as visitors')
            ->whereNotNull('path')
            ->groupBy('path')
            ->orderByDesc('views')
            ->limit(10)
            ->get()
            ->map(fn (Model $row): array => [
                'path' => $row->path,
                'title' => $row->title,
                'views' => (int) $row->views,
                'visitors' => (int) $row->visitors,
            ])
            ->all();
    }

    /**
     * @return array<int, array{referrer: string, views: int}>
     */
    public function getTopReferrers(): array
    {
        return $this->eventsQuery()
            ->selectRaw('COALESCE(NULLIF(referrer, ""), "Direct / none") as referrer_label, COUNT(*) as views')
            ->groupByRaw('COALESCE(NULLIF(referrer, ""), "Direct / none")')
            ->orderByDesc('views')
            ->limit(10)
            ->get()
            ->map(fn (Model $row): array => [
                'referrer' => $row->referrer_label,
                'views' => (int) $row->views,
            ])
            ->all();
    }

    /**
     * @return array<int, array{occurred_at: string, path: string|null, title: string|null, referrer: string|null}>
     */
    public function getRecentVisits(): array
    {
        return $this->eventsQuery()
            ->latest('occurred_at')
            ->limit(10)
            ->get(['occurred_at', 'path', 'title', 'referrer'])
            ->map(fn (Model $row): array => [
                'occurred_at' => $row->occurred_at?->format('Y-m-d H:i') ?? '-',
                'path' => $row->path,
                'title' => $row->title,
                'referrer' => $row->referrer,
            ])
            ->all();
    }

    public function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }

    protected function authorizeAccess(): void
    {
        abort_unless(static::getResource()::canView($this->getRecord()), 403);
    }

    protected function eventsQuery(): Builder
    {
        return $this->getRecord()->trackerEvents()->getQuery();
    }
}
