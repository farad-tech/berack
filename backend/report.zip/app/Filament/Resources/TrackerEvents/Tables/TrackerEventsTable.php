<?php

namespace App\Filament\Resources\TrackerEvents\Tables;

use Filament\Actions\ViewAction;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Filters\SelectFilter;
use Filament\Tables\Table;

class TrackerEventsTable
{
    public static function configure(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('site.name')
                    ->label(static::t('سایت', 'Site'))
                    ->searchable()
                    ->sortable(),
                TextColumn::make('event_name')
                    ->label(static::t('نوع رویداد', 'Event'))
                    ->searchable(),
                TextColumn::make('path')
                    ->label(static::t('مسیر صفحه', 'Path'))
                    ->searchable(),
                TextColumn::make('title')
                    ->label(static::t('عنوان صفحه', 'Title'))
                    ->searchable(),
                TextColumn::make('referrer')
                    ->label(static::t('ارجاع‌دهنده', 'Referrer'))
                    ->limit(36)
                    ->placeholder(static::t('مستقیم / بدون ارجاع', 'Direct / none'))
                    ->toggleable(),
                TextColumn::make('payload.language')
                    ->label(static::t('زبان', 'Language'))
                    ->placeholder('-')
                    ->toggleable(),
                TextColumn::make('payload.viewport.width')
                    ->label(static::t('اندازه مرورگر', 'Viewport'))
                    ->formatStateUsing(fn ($record): string => ($record->payload['viewport']['width'] ?? '-') . ' x ' . ($record->payload['viewport']['height'] ?? '-'))
                    ->toggleable(),
                TextColumn::make('payload.sdk_version')
                    ->label('SDK')
                    ->placeholder('-')
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('anonymous_id')
                    ->label(static::t('شناسه بازدیدکننده', 'Visitor ID'))
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('session_id')
                    ->label(static::t('شناسه نشست', 'Session ID'))
                    ->searchable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('sequence')
                    ->label(static::t('ترتیب', 'Sequence'))
                    ->numeric()
                    ->sortable(),
                TextColumn::make('occurred_at')
                    ->label(static::t('زمان وقوع', 'Occurred at'))
                    ->dateTime()
                    ->sortable(),
                TextColumn::make('created_at')
                    ->label(static::t('تاریخ ثبت', 'Created at'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
                TextColumn::make('updated_at')
                    ->label(static::t('آخرین تغییر', 'Updated at'))
                    ->dateTime()
                    ->sortable()
                    ->toggleable(isToggledHiddenByDefault: true),
            ])
            ->filters([
                SelectFilter::make('site_id')
                    ->label(static::t('سایت', 'Site'))
                    ->relationship('site', 'name', fn ($query) => $query->where('user_id', auth()->id())),
            ])
            ->recordActions([
                ViewAction::make(),
            ])
            ->toolbarActions([]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
