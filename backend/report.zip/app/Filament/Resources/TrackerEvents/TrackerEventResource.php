<?php

namespace App\Filament\Resources\TrackerEvents;

use App\Filament\Resources\TrackerEvents\Pages\ListTrackerEvents;
use App\Filament\Resources\TrackerEvents\Pages\ViewTrackerEvent;
use App\Filament\Resources\TrackerEvents\Schemas\TrackerEventForm;
use App\Filament\Resources\TrackerEvents\Schemas\TrackerEventInfolist;
use App\Filament\Resources\TrackerEvents\Tables\TrackerEventsTable;
use App\Models\TrackerEvent;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;

class TrackerEventResource extends Resource
{
    protected static ?string $model = TrackerEvent::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::ChartBarSquare;

    protected static ?int $navigationSort = 20;

    public static function getNavigationGroup(): ?string
    {
        return app()->getLocale() === 'fa' ? 'گزارش‌ها' : 'Reports';
    }

    public static function getNavigationLabel(): string
    {
        return app()->getLocale() === 'fa' ? 'آمار بازدید' : 'Analytics';
    }

    public static function getModelLabel(): string
    {
        return app()->getLocale() === 'fa' ? 'رویداد' : 'Event';
    }

    public static function getPluralModelLabel(): string
    {
        return app()->getLocale() === 'fa' ? 'آمار بازدید' : 'Analytics';
    }

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()
            ->whereHas('site', fn (Builder $query): Builder => $query->where('user_id', auth()->id()));
    }

    public static function canCreate(): bool
    {
        return false;
    }

    public static function canEdit($record): bool
    {
        return false;
    }

    public static function canDelete($record): bool
    {
        return false;
    }

    public static function form(Schema $schema): Schema
    {
        return TrackerEventForm::configure($schema);
    }

    public static function infolist(Schema $schema): Schema
    {
        return TrackerEventInfolist::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return TrackerEventsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [
            //
        ];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListTrackerEvents::route('/'),
            'view' => ViewTrackerEvent::route('/{record}'),
        ];
    }
}
