<?php

namespace App\Filament\Resources\TrackerEvents\Schemas;

use Filament\Infolists\Components\TextEntry;
use Filament\Schemas\Schema;

class TrackerEventInfolist
{
    public static function configure(Schema $schema): Schema
    {
        return $schema
            ->components([
                TextEntry::make('site.name')
                    ->label(static::t('سایت', 'Site')),
                TextEntry::make('event_id')
                    ->label('Event ID'),
                TextEntry::make('event_name')
                    ->label(static::t('نوع رویداد', 'Event')),
                TextEntry::make('anonymous_id')
                    ->label(static::t('شناسه بازدیدکننده', 'Visitor ID'))
                    ->placeholder('-'),
                TextEntry::make('session_id')
                    ->label(static::t('شناسه نشست', 'Session ID'))
                    ->placeholder('-'),
                TextEntry::make('sequence')
                    ->label(static::t('ترتیب', 'Sequence'))
                    ->numeric()
                    ->placeholder('-'),
                TextEntry::make('url')
                    ->label('URL')
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('path')
                    ->label(static::t('مسیر صفحه', 'Path'))
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('title')
                    ->label(static::t('عنوان صفحه', 'Title'))
                    ->placeholder('-'),
                TextEntry::make('previous_url')
                    ->label(static::t('آدرس قبلی', 'Previous URL'))
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('referrer')
                    ->label(static::t('ارجاع‌دهنده', 'Referrer'))
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('payload.language')
                    ->label(static::t('زبان', 'Language'))
                    ->placeholder('-'),
                TextEntry::make('payload.sdk_version')
                    ->label('SDK version')
                    ->placeholder('-'),
                TextEntry::make('payload.user_agent')
                    ->label('User agent')
                    ->placeholder('-')
                    ->columnSpanFull(),
                TextEntry::make('payload.viewport.width')
                    ->label(static::t('اندازه مرورگر', 'Viewport'))
                    ->state(fn ($record): string => ($record->payload['viewport']['width'] ?? '-') . ' x ' . ($record->payload['viewport']['height'] ?? '-')),
                TextEntry::make('payload.screen.width')
                    ->label(static::t('اندازه صفحه نمایش', 'Screen'))
                    ->state(fn ($record): string => ($record->payload['screen']['width'] ?? '-') . ' x ' . ($record->payload['screen']['height'] ?? '-')),
                TextEntry::make('occurred_at')
                    ->label(static::t('زمان وقوع', 'Occurred at'))
                    ->dateTime()
                    ->placeholder('-'),
                TextEntry::make('payload')
                    ->label(static::t('داده خام', 'Raw payload'))
                    ->columnSpanFull(),
                TextEntry::make('created_at')
                    ->label(static::t('تاریخ ثبت', 'Created at'))
                    ->dateTime()
                    ->placeholder('-'),
                TextEntry::make('updated_at')
                    ->label(static::t('آخرین تغییر', 'Updated at'))
                    ->dateTime()
                    ->placeholder('-'),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
