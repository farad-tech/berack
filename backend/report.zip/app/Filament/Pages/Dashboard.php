<?php

namespace App\Filament\Pages;

use Filament\Pages\Dashboard as BaseDashboard;

class Dashboard extends BaseDashboard
{
    public function getTitle(): string
    {
        return app()->getLocale() === 'fa' ? 'داشبورد براک' : 'Berack dashboard';
    }

    public static function getNavigationLabel(): string
    {
        return app()->getLocale() === 'fa' ? 'داشبورد' : 'Dashboard';
    }
}
