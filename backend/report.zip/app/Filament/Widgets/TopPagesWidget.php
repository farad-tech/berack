<?php

namespace App\Filament\Widgets;

use App\Models\TrackerEvent;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;

class TopPagesWidget extends TableWidget
{
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->heading(static::t('صفحه‌های پربازدید', 'Top pages'))
            ->query(
                TrackerEvent::forUser(auth()->id())
                    ->selectRaw('MIN(id) as id, path, MAX(title) as title, COUNT(*) as views, COUNT(DISTINCT anonymous_id) as visitors')
                    ->whereNotNull('path')
                    ->groupBy('path')
                    ->orderByDesc('views')
                    ->limit(10)
            )
            ->defaultKeySort(false)
            ->columns([
                TextColumn::make('path')
                    ->label(static::t('مسیر صفحه', 'Path'))
                    ->searchable(),
                TextColumn::make('title')
                    ->label(static::t('آخرین عنوان', 'Last title'))
                    ->placeholder('-')
                    ->limit(40),
                TextColumn::make('views')
                    ->label(static::t('بازدیدها', 'Views'))
                    ->numeric()
                    ->sortable(),
                TextColumn::make('visitors')
                    ->label(static::t('بازدیدکننده‌های یکتا', 'Unique visitors'))
                    ->numeric(),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
