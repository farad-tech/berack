<?php

namespace App\Filament\Widgets;

use App\Models\TrackerEvent;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;

class RecentVisitsWidget extends TableWidget
{
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->heading(static::t('آخرین بازدیدها', 'Recent visits'))
            ->query(
                TrackerEvent::forUser(auth()->id())
                    ->with('site')
                    ->latest('occurred_at')
                    ->limit(10)
            )
            ->columns([
                TextColumn::make('occurred_at')
                    ->label(static::t('زمان', 'Time'))
                    ->dateTime()
                    ->sortable(),
                TextColumn::make('site.name')
                    ->label(static::t('سایت', 'Site')),
                TextColumn::make('path')
                    ->label(static::t('مسیر صفحه', 'Path'))
                    ->searchable(),
                TextColumn::make('title')
                    ->label(static::t('عنوان', 'Title'))
                    ->limit(40)
                    ->placeholder('-'),
                TextColumn::make('referrer')
                    ->label(static::t('ارجاع‌دهنده', 'Referrer'))
                    ->limit(50)
                    ->placeholder(static::t('مستقیم / بدون ارجاع', 'Direct / none')),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
