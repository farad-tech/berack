<?php

namespace App\Filament\Widgets;

use App\Models\Site;
use App\Models\TrackerEvent;
use Filament\Widgets\StatsOverviewWidget;
use Filament\Widgets\StatsOverviewWidget\Stat;

class AnalyticsStats extends StatsOverviewWidget
{
    protected function getStats(): array
    {
        $userId = auth()->id();

        $sitesCount = Site::where('user_id', $userId)->count();
        $eventsQuery = TrackerEvent::forUser($userId);
        $todayEvents = (clone $eventsQuery)->whereDate('occurred_at', today())->count();
        $yesterdayEvents = (clone $eventsQuery)->whereDate('occurred_at', today()->subDay())->count();
        $uniqueVisitors = (clone $eventsQuery)->whereNotNull('anonymous_id')->distinct('anonymous_id')->count('anonymous_id');
        $sessions = (clone $eventsQuery)->whereNotNull('session_id')->distinct('session_id')->count('session_id');
        $activePages = (clone $eventsQuery)->whereNotNull('path')->distinct('path')->count('path');
        $activeSites = Site::where('user_id', $userId)
            ->whereHas('trackerEvents')
            ->count();

        return [
            Stat::make(static::t('سایت‌ها', 'Sites'), $sitesCount)
                ->description(static::t($activeSites . ' سایت فعال', $activeSites . ' active')),
            Stat::make(static::t('کل بازدید صفحات', 'Total page views'), (clone $eventsQuery)->count()),
            Stat::make(static::t('بازدیدهای امروز', 'Page views today'), $todayEvents)
                ->description(static::t(($todayEvents - $yesterdayEvents) . ' نسبت به دیروز', ($todayEvents - $yesterdayEvents) . ' vs yesterday')),
            Stat::make(static::t('بازدیدکننده‌های یکتا', 'Unique visitors'), $uniqueVisitors),
            Stat::make(static::t('نشست‌ها', 'Sessions'), $sessions),
            Stat::make(static::t('صفحه‌های ردیابی‌شده', 'Tracked pages'), $activePages),
        ];
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
