<?php

namespace App\Filament\Widgets;

use App\Models\TrackerEvent;
use Filament\Widgets\ChartWidget;

class PageViewsChart extends ChartWidget
{
    protected string $color = 'primary';

    public function getHeading(): string
    {
        return app()->getLocale() === 'fa' ? 'روند بازدید صفحات در ۱۴ روز اخیر' : 'Page views over the last 14 days';
    }

    protected function getData(): array
    {
        $userId = auth()->id();
        $start = today()->subDays(13);
        $labels = [];
        $values = [];

        $counts = TrackerEvent::forUser($userId)
            ->whereDate('occurred_at', '>=', $start)
            ->selectRaw('DATE(occurred_at) as event_date, COUNT(*) as views')
            ->groupBy('event_date')
            ->pluck('views', 'event_date');

        for ($day = $start->copy(); $day <= today(); $day->addDay()) {
            $key = $day->toDateString();
            $labels[] = $day->format('M j');
            $values[] = (int) ($counts[$key] ?? 0);
        }

        return [
            'datasets' => [
                [
                    'label' => app()->getLocale() === 'fa' ? 'بازدید صفحات' : 'Page views',
                    'data' => $values,
                ],
            ],
            'labels' => $labels,
        ];
    }

    protected function getType(): string
    {
        return 'line';
    }
}
