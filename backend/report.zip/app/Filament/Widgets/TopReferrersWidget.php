<?php

namespace App\Filament\Widgets;

use App\Models\TrackerEvent;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Filament\Widgets\TableWidget;

class TopReferrersWidget extends TableWidget
{
    protected int | string | array $columnSpan = 'full';

    public function table(Table $table): Table
    {
        return $table
            ->heading(static::t('بهترین منابع ورودی', 'Top referrers'))
            ->query(
                TrackerEvent::forUser(auth()->id())
                    ->selectRaw('MIN(id) as id, COALESCE(NULLIF(referrer, ""), \'Direct / none\') as referrer_label, COUNT(*) as views')
                    ->groupBy('referrer_label')
                    ->orderByDesc('views')
                    ->limit(10)
            )
            ->defaultKeySort(false)
            ->columns([
                TextColumn::make('referrer_label')
                    ->label(static::t('ارجاع‌دهنده', 'Referrer'))
                    ->limit(80),
                TextColumn::make('views')
                    ->label(static::t('بازدیدها', 'Views'))
                    ->numeric()
                    ->sortable(),
            ]);
    }

    private static function t(string $fa, string $en): string
    {
        return app()->getLocale() === 'fa' ? $fa : $en;
    }
}
