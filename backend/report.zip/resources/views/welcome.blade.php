@php
    $isFa = ($locale ?? 'fa') === 'fa';
    $dir = $isFa ? 'rtl' : 'ltr';
    $lang = $isFa ? 'fa' : 'en';
    $registerUrl = url('/panel/register');
    $loginUrl = url('/panel');
    $guideUrl = $isFa ? url('/guide') : url('/en/guide');
    $switchUrl = $isFa ? url('/en') : url('/');

    $copy = $isFa ? [
        'switch' => 'English',
        'login' => 'ورود به پنل',
        'guide' => 'راهنما',
        'register' => 'ثبت نام رایگان',
        'eyebrow' => 'Berack، ترکیب behaviour tracker',
        'title' => 'رفتار کاربران سایتتان را ساده، خصوصی و قابل فهم ببینید.',
        'lead' => 'Berack یک behaviour tracker متن باز و self-hosted است: کاربر ثبت نام می کند، سایتش را اضافه می کند، API key و لینک SDK می گیرد و آمار بازدید صفحه ها را در پنل خودش می بیند.',
        'secondary' => 'دیدن نمونه جریان کار',
        'metric1' => 'بازدید امروز',
        'metric2' => 'صفحات فعال',
        'metric3' => 'کاربران یکتا',
        'panelTitle' => 'نمای زنده پنل',
        'panelSub' => 'هر سایت، کلید و آمار خودش را دارد.',
        'chartTitle' => 'page_view در ۷ روز گذشته',
        'topPages' => 'صفحات پربازدید',
        'workflowTitle' => 'از ثبت نام تا دریافت آمار در چند دقیقه',
        'workflowLead' => 'تمرکز پروژه روی راه اندازی سریع و مالکیت کامل داده هاست.',
        'steps' => [
            ['ثبت نام', 'کاربر از مسیر Filament ثبت نام می کند و وارد پنل خودش می شود.'],
            ['ثبت سایت', 'نام و دامنه سایت را وارد می کند و API key اختصاصی می گیرد.'],
            ['نصب SDK', 'لینک SDK را در سایت قرار می دهد و بازدیدها به backend ارسال می شوند.'],
            ['مشاهده آمار', 'بازدیدها، مسیرها و sessionها فقط در پنل همان کاربر نمایش داده می شوند.'],
        ],
        'featuresTitle' => 'چیزی که همین حالا آماده است',
        'features' => [
            'ثبت نام و ورود با Filament',
            'چند سایت برای هر کاربر',
            'API key اختصاصی برای هر سایت',
            'SDK سبک برای ثبت page view',
            'جداسازی آمار هر کاربر',
            'مناسب برای توسعه self-hosted',
        ],
        'contactTitle' => 'ارتباط با سازنده',
        'contactLead' => 'برای پیشنهاد، همکاری یا سوال درباره Berack می توانید مستقیم پیام بدهید.',
        'contactAction' => 'ارسال ایمیل',
        'ctaTitle' => 'اولین سایتت را ثبت کن',
        'ctaLead' => 'حساب بساز، سایت را اضافه کن و snippet آماده SDK را از پنل کپی کن.',
    ] : [
        'switch' => 'فارسی',
        'login' => 'Open panel',
        'guide' => 'Guide',
        'register' => 'Create free account',
        'eyebrow' => 'Berack, short for behaviour tracker',
        'title' => 'Understand where your users go, without giving up your data.',
        'lead' => 'Berack is an open-source, self-hosted behaviour tracker: users register, add a website, receive an API key and SDK URL, then view page analytics inside their own panel.',
        'secondary' => 'See the workflow',
        'metric1' => 'Views today',
        'metric2' => 'Active pages',
        'metric3' => 'Unique users',
        'panelTitle' => 'Live panel preview',
        'panelSub' => 'Each site gets its own key and analytics.',
        'chartTitle' => 'page_view over the last 7 days',
        'topPages' => 'Top pages',
        'workflowTitle' => 'From signup to analytics in minutes',
        'workflowLead' => 'The project is designed for fast setup and full ownership of your analytics data.',
        'steps' => [
            ['Sign up', 'Users register through Filament and enter their own panel.'],
            ['Add a site', 'They enter a site name and domain, then receive a dedicated API key.'],
            ['Install SDK', 'They paste the SDK script into the website and events flow to the backend.'],
            ['View analytics', 'Page views, paths, and sessions are shown only to that user.'],
        ],
        'featuresTitle' => 'Ready today',
        'features' => [
            'Filament registration and login',
            'Multiple sites per user',
            'Dedicated API key per site',
            'Lightweight page view SDK',
            'Per-user analytics isolation',
            'Self-hosted development friendly',
        ],
        'contactTitle' => 'Contact the creator',
        'contactLead' => 'For feedback, collaboration, or questions about Berack, you can reach out directly.',
        'contactAction' => 'Send email',
        'ctaTitle' => 'Register your first site',
        'ctaLead' => 'Create an account, add your website, and copy the generated SDK snippet from the panel.',
    ];
@endphp

<!doctype html>
<html lang="{{ $lang }}" dir="{{ $dir }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Berack</title>
    <meta name="description" content="Berack is an open-source behaviour tracker with Laravel, Filament, and a lightweight JavaScript SDK.">
    <link href="{{ url('/assets/fonts/vazirmatn.css') }}" rel="stylesheet">
    <style>
        :root {
            color-scheme: light;
            --ink: #17211b;
            --muted: #64716a;
            --line: #dce5df;
            --paper: #fbfcf9;
            --panel: #ffffff;
            --green: #1f7a5b;
            --green-dark: #15533f;
            --amber: #d7972f;
            --blue: #3662a8;
            --rose: #b85265;
        }

        * { box-sizing: border-box; }

        html {
            scroll-behavior: smooth;
        }

        body {
            margin: 0;
            background: var(--paper);
            color: var(--ink);
            font-family: "Vazirmatn", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            line-height: 1.7;
        }

        a { color: inherit; text-decoration: none; }

        .shell {
            width: min(1120px, calc(100% - 32px));
            margin-inline: auto;
        }

        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 22px 0;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 10px;
            font-weight: 800;
            letter-spacing: 0;
        }

        .mark {
            display: grid;
            place-items: center;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: var(--ink);
            color: #fff;
            font-weight: 900;
        }

        .nav-actions {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
            justify-content: flex-end;
        }

        .link {
            color: var(--muted);
            font-weight: 650;
            font-size: 14px;
        }

        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 44px;
            border-radius: 8px;
            padding: 0 18px;
            font-weight: 800;
            border: 1px solid var(--line);
            background: #fff;
            color: var(--ink);
            white-space: nowrap;
        }

        .button.primary {
            border-color: var(--green);
            background: var(--green);
            color: #fff;
        }

        .hero {
            display: grid;
            grid-template-columns: minmax(0, 1fr) minmax(360px, 520px);
            gap: 48px;
            align-items: center;
            padding: 42px 0 68px;
        }

        .eyebrow {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--green-dark);
            font-weight: 800;
            background: #e5f3ec;
            border: 1px solid #c6dfd2;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 13px;
        }

        h1 {
            margin: 20px 0 18px;
            max-width: 780px;
            font-size: clamp(38px, 6vw, 72px);
            line-height: 1.08;
            letter-spacing: 0;
        }

        .lead {
            max-width: 680px;
            color: var(--muted);
            font-size: clamp(17px, 2vw, 20px);
        }

        .hero-actions {
            display: flex;
            gap: 12px;
            flex-wrap: wrap;
            margin-top: 30px;
        }

        .product-shot {
            border: 1px solid #cfd9d3;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 24px 70px rgba(23, 33, 27, .14);
            overflow: hidden;
        }

        .window-bar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            min-height: 48px;
            padding: 0 16px;
            border-bottom: 1px solid var(--line);
            background: #f3f7f4;
        }

        .dots {
            display: flex;
            gap: 7px;
        }

        .dot {
            width: 10px;
            height: 10px;
            border-radius: 50%;
        }

        .dot:nth-child(1) { background: var(--rose); }
        .dot:nth-child(2) { background: var(--amber); }
        .dot:nth-child(3) { background: var(--green); }

        .panel-label {
            color: var(--muted);
            font-size: 13px;
            font-weight: 750;
        }

        .dashboard {
            padding: 22px;
        }

        .dash-head {
            display: flex;
            justify-content: space-between;
            gap: 18px;
            align-items: flex-start;
            margin-bottom: 22px;
        }

        .dash-title {
            font-weight: 900;
            font-size: 20px;
        }

        .dash-sub {
            color: var(--muted);
            font-size: 13px;
        }

        .pill {
            border: 1px solid #cfe0d6;
            background: #eef8f2;
            color: var(--green-dark);
            border-radius: 999px;
            padding: 5px 10px;
            font-size: 12px;
            font-weight: 800;
            white-space: nowrap;
        }

        .stats {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-bottom: 18px;
        }

        .stat {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 13px;
            background: #fff;
        }

        .stat strong {
            display: block;
            font-size: 22px;
            line-height: 1.2;
        }

        .stat span {
            display: block;
            color: var(--muted);
            font-size: 12px;
            margin-top: 4px;
        }

        .chart {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 16px;
            background: linear-gradient(180deg, #ffffff, #f9fbfa);
        }

        .chart-title {
            color: var(--muted);
            font-size: 13px;
            font-weight: 750;
            margin-bottom: 18px;
        }

        .bars {
            display: grid;
            grid-template-columns: repeat(7, 1fr);
            align-items: end;
            gap: 10px;
            height: 150px;
        }

        .bar {
            min-height: 18px;
            border-radius: 6px 6px 2px 2px;
            background: var(--green);
        }

        .bar:nth-child(2) { background: var(--blue); }
        .bar:nth-child(4) { background: var(--amber); }
        .bar:nth-child(6) { background: var(--rose); }

        .pages {
            display: grid;
            gap: 10px;
            margin-top: 16px;
        }

        .page-row {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 10px;
            align-items: center;
            color: var(--muted);
            font-size: 13px;
        }

        .section {
            padding: 64px 0;
            border-top: 1px solid var(--line);
        }

        .section-head {
            max-width: 720px;
            margin-bottom: 32px;
        }

        h2 {
            margin: 0 0 10px;
            font-size: clamp(28px, 4vw, 44px);
            line-height: 1.16;
            letter-spacing: 0;
        }

        .section-head p {
            margin: 0;
            color: var(--muted);
            font-size: 18px;
        }

        .steps {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 14px;
        }

        .step,
        .feature {
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fff;
            padding: 20px;
        }

        .num {
            display: inline-grid;
            place-items: center;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: #edf6f1;
            color: var(--green-dark);
            font-weight: 900;
            margin-bottom: 14px;
        }

        .step h3,
        .feature h3 {
            margin: 0 0 8px;
            font-size: 18px;
        }

        .step p,
        .feature p {
            margin: 0;
            color: var(--muted);
            font-size: 15px;
        }

        .features {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 14px;
        }

        .feature {
            display: flex;
            align-items: center;
            gap: 12px;
            font-weight: 800;
        }

        .check {
            display: grid;
            place-items: center;
            flex: 0 0 auto;
            width: 28px;
            height: 28px;
            border-radius: 50%;
            background: var(--green);
            color: #fff;
            font-size: 15px;
        }

        .cta-band {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 24px;
            align-items: center;
            background: var(--ink);
            color: #fff;
            border-radius: 8px;
            padding: 34px;
        }

        .contact-band {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 22px;
            align-items: center;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fff;
            padding: 28px;
        }

        .contact-band p {
            margin: 6px 0 0;
            color: var(--muted);
        }

        .email-link {
            color: var(--green-dark);
            font-weight: 900;
            direction: ltr;
            unicode-bidi: isolate;
        }

        .cta-band p {
            margin: 8px 0 0;
            color: #c7d2cc;
        }

        footer {
            color: var(--muted);
            padding: 28px 0 42px;
            font-size: 14px;
        }

        @media (max-width: 920px) {
            .hero,
            .contact-band,
            .cta-band {
                grid-template-columns: 1fr;
            }

            .steps,
            .features {
                grid-template-columns: repeat(2, 1fr);
            }
        }

        @media (max-width: 640px) {
            .shell {
                width: min(100% - 24px, 1120px);
            }

            .nav {
                align-items: flex-start;
            }

            .nav-actions {
                gap: 8px;
            }

            .button {
                min-height: 40px;
                padding: 0 13px;
                font-size: 14px;
            }

            .hero {
                padding-top: 28px;
            }

            .stats,
            .steps,
            .features {
                grid-template-columns: 1fr;
            }

            .dash-head {
                display: block;
            }

            .pill {
                display: inline-flex;
                margin-top: 12px;
            }

            .cta-band {
                padding: 24px;
            }
        }
    </style>
</head>
<body>
    <header class="shell nav">
        <a class="brand" href="{{ $isFa ? url('/') : url('/en') }}" aria-label="Berack">
            <span class="mark">OT</span>
            <span>Berack</span>
        </a>
        <nav class="nav-actions" aria-label="Primary">
            <a class="link" href="{{ $switchUrl }}">{{ $copy['switch'] }}</a>
            <a class="link" href="{{ $guideUrl }}">{{ $copy['guide'] }}</a>
            <a class="link" href="{{ $loginUrl }}">{{ $copy['login'] }}</a>
            <a class="button primary" href="{{ $registerUrl }}">{{ $copy['register'] }}</a>
        </nav>
    </header>

    <main>
        <section class="shell hero">
            <div>
                <span class="eyebrow">{{ $copy['eyebrow'] }}</span>
                <h1>{{ $copy['title'] }}</h1>
                <p class="lead">{{ $copy['lead'] }}</p>
                <div class="hero-actions">
                    <a class="button primary" href="{{ $registerUrl }}">{{ $copy['register'] }}</a>
                    <a class="button" href="#workflow">{{ $copy['secondary'] }}</a>
                </div>
            </div>

            <div class="product-shot" aria-label="{{ $copy['panelTitle'] }}">
                <div class="window-bar">
                    <div class="dots" aria-hidden="true">
                        <span class="dot"></span>
                        <span class="dot"></span>
                        <span class="dot"></span>
                    </div>
                    <span class="panel-label">berack.test/panel</span>
                </div>
                <div class="dashboard">
                    <div class="dash-head">
                        <div>
                            <div class="dash-title">{{ $copy['panelTitle'] }}</div>
                            <div class="dash-sub">{{ $copy['panelSub'] }}</div>
                        </div>
                        <span class="pill">SDK active</span>
                    </div>
                    <div class="stats">
                        <div class="stat"><strong>1,284</strong><span>{{ $copy['metric1'] }}</span></div>
                        <div class="stat"><strong>36</strong><span>{{ $copy['metric2'] }}</span></div>
                        <div class="stat"><strong>812</strong><span>{{ $copy['metric3'] }}</span></div>
                    </div>
                    <div class="chart">
                        <div class="chart-title">{{ $copy['chartTitle'] }}</div>
                        <div class="bars" aria-hidden="true">
                            <span class="bar" style="height: 42%"></span>
                            <span class="bar" style="height: 64%"></span>
                            <span class="bar" style="height: 52%"></span>
                            <span class="bar" style="height: 78%"></span>
                            <span class="bar" style="height: 58%"></span>
                            <span class="bar" style="height: 88%"></span>
                            <span class="bar" style="height: 70%"></span>
                        </div>
                    </div>
                    <div class="pages" aria-label="{{ $copy['topPages'] }}">
                        <div class="page-row"><span>/pricing</span><strong>428</strong></div>
                        <div class="page-row"><span>/docs/install</span><strong>316</strong></div>
                        <div class="page-row"><span>/dashboard</span><strong>204</strong></div>
                    </div>
                </div>
            </div>
        </section>

        <section class="section" id="workflow">
            <div class="shell">
                <div class="section-head">
                    <h2>{{ $copy['workflowTitle'] }}</h2>
                    <p>{{ $copy['workflowLead'] }}</p>
                </div>
                <div class="steps">
                    @foreach ($copy['steps'] as $index => $step)
                        <article class="step">
                            <span class="num">{{ $index + 1 }}</span>
                            <h3>{{ $step[0] }}</h3>
                            <p>{{ $step[1] }}</p>
                        </article>
                    @endforeach
                </div>
            </div>
        </section>

        <section class="section">
            <div class="shell">
                <div class="section-head">
                    <h2>{{ $copy['featuresTitle'] }}</h2>
                </div>
                <div class="features">
                    @foreach ($copy['features'] as $feature)
                        <div class="feature">
                            <span class="check">✓</span>
                            <span>{{ $feature }}</span>
                        </div>
                    @endforeach
                </div>
            </div>
        </section>

        <section class="section" id="contact">
            <div class="shell">
                <div class="contact-band">
                    <div>
                        <h2>{{ $copy['contactTitle'] }}</h2>
                        <p>{{ $copy['contactLead'] }}</p>
                    </div>
                    <a class="button email-link" href="mailto:farhadkarami@yahoo.com">
                        {{ $copy['contactAction'] }} · farhadkarami@yahoo.com
                    </a>
                </div>
            </div>
        </section>

        <section class="section">
            <div class="shell">
                <div class="cta-band">
                    <div>
                        <h2>{{ $copy['ctaTitle'] }}</h2>
                        <p>{{ $copy['ctaLead'] }}</p>
                    </div>
                    <a class="button primary" href="{{ $registerUrl }}">{{ $copy['register'] }}</a>
                </div>
            </div>
        </section>
    </main>

    <footer class="shell">
        Berack · Laravel + Filament + JavaScript SDK
    </footer>
</body>
</html>
