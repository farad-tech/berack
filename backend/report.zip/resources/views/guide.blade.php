@php
    $isFa = ($locale ?? 'fa') === 'fa';
    $dir = $isFa ? 'rtl' : 'ltr';
    $lang = $isFa ? 'fa' : 'en';
    $homeUrl = $isFa ? url('/') : url('/en');
    $switchUrl = $isFa ? url('/en/guide') : url('/guide');
    $registerUrl = url('/panel/register');
    $loginUrl = url('/panel');

    $copy = $isFa ? [
        'switch' => 'English',
        'back' => 'صفحه اصلی',
        'login' => 'ورود به پنل',
        'register' => 'ثبت نام رایگان',
        'eyebrow' => 'راهنمای شروع Berack',
        'title' => 'چطور سایتتان را به Berack وصل کنید و آمار را در پنل ببینید',
        'lead' => 'این راهنما برای کاربرانی است که وارد سایت می شوند، حساب می سازند، سایتشان را ثبت می کنند و تگ Berack را در سایت خودشان قرار می دهند.',
        'tocTitle' => 'مسیر سریع',
        'sections' => [
            ['account', '۱. ساخت حساب و ورود به پنل'],
            ['site', '۲. ثبت سایت'],
            ['tag', '۳. دریافت و نصب تگ Berack'],
            ['verify', '۴. تست نصب'],
            ['analytics', '۵. مشاهده آمار'],
            ['troubleshooting', 'رفع اشکال'],
        ],
        'accountTitle' => '۱. ساخت حساب و ورود به پنل',
        'accountBody' => 'از دکمه ثبت نام، حساب کاربری بسازید. بعد از ثبت نام وارد پنل کاربری می شوید. از دفعات بعد می توانید مستقیم از مسیر ورود به پنل استفاده کنید.',
        'siteTitle' => '۲. ثبت سایت',
        'siteBody' => 'در پنل، وارد بخش Sites شوید و گزینه Create را بزنید. نام سایت و دامنه را وارد کنید. Berack برای هر سایت یک API key اختصاصی می سازد.',
        'tagTitle' => '۳. دریافت و نصب تگ Berack',
        'tagBody' => 'بعد از ساخت سایت، وارد صفحه جزئیات همان سایت شوید. قسمت Install snippet را کپی کنید و قبل از بسته شدن تگ head در سایت خودتان قرار دهید.',
        'exampleTitle' => 'نمونه تگ نصب',
        'htmlTitle' => 'HTML ساده',
        'spaTitle' => 'React / Vue / SPA',
        'wpTitle' => 'WordPress',
        'htmlBody' => 'تگ را داخل فایل layout اصلی سایت، قبل از </head> قرار دهید.',
        'spaBody' => 'تگ را در فایل HTML اصلی برنامه، مثل index.html، قرار دهید. Berack تغییر مسیرهای SPA را هم با pushState، replaceState، back و forward ثبت می کند.',
        'wpBody' => 'اگر قالب را مستقیم ویرایش می کنید، تگ را در header.php قبل از </head> بگذارید. اگر از افزونه header scripts استفاده می کنید، snippet را همان جا اضافه کنید.',
        'verifyTitle' => '۴. تست نصب',
        'verifyBody' => 'بعد از نصب تگ، سایت را باز کنید و چند صفحه را مشاهده کنید. سپس به پنل Berack برگردید و بخش Analytics را بررسی کنید. اگر همه چیز درست باشد، page_viewها باید ثبت شده باشند.',
        'analyticsTitle' => '۵. مشاهده آمار',
        'analyticsBody' => 'در پنل کاربری، بخش Analytics eventهای سایت های شما را نشان می دهد. هر کاربر فقط سایت ها و آمار خودش را می بیند.',
        'analyticsItems' => [
            'آدرس صفحه و path',
            'عنوان صفحه',
            'referrer و previous URL',
            'شناسه ناشناس کاربر و session',
            'زمان ثبت event',
            'اطلاعات viewport و screen در payload',
        ],
        'troubleTitle' => 'رفع اشکال',
        'troubleItems' => [
            ['آماری نمی بینم', 'مطمئن شوید snippet دقیقاً از پنل همان سایت کپی شده و داخل head سایت قرار گرفته است.'],
            ['API key اشتباه است', 'برای هر سایت، API key جدا ساخته می شود. اگر چند سایت دارید، snippet هر سایت را با خودش استفاده کنید.'],
            ['سایت من SPA است', 'نیازی به کد اضافه نیست؛ SDK تغییر URLهای SPA را هم ثبت می کند.'],
            ['در local تست می کنم', 'آدرس backend در snippet باید به همان دامنه ای اشاره کند که Laravel روی آن اجرا می شود.'],
        ],
        'ctaTitle' => 'آماده ای شروع کنی؟',
        'ctaLead' => 'حساب بساز، سایتت را ثبت کن و تگ Berack را در کمتر از چند دقیقه نصب کن.',
    ] : [
        'switch' => 'فارسی',
        'back' => 'Home',
        'login' => 'Open panel',
        'register' => 'Create free account',
        'eyebrow' => 'Berack getting started guide',
        'title' => 'How to connect your website to Berack and view analytics',
        'lead' => 'This guide is for users who sign up, add a website, install the Berack tag, and read analytics inside their panel.',
        'tocTitle' => 'Quick path',
        'sections' => [
            ['account', '1. Create an account'],
            ['site', '2. Add your website'],
            ['tag', '3. Get and install the Berack tag'],
            ['verify', '4. Verify installation'],
            ['analytics', '5. View analytics'],
            ['troubleshooting', 'Troubleshooting'],
        ],
        'accountTitle' => '1. Create an account',
        'accountBody' => 'Use the registration button to create an account. After signing up, you enter your user panel. Later, use the panel login link directly.',
        'siteTitle' => '2. Add your website',
        'siteBody' => 'Inside the panel, open Sites and click Create. Enter your site name and domain. Berack generates a dedicated API key for each site.',
        'tagTitle' => '3. Get and install the Berack tag',
        'tagBody' => 'After creating a site, open its detail page. Copy the Install snippet and paste it before the closing head tag on your website.',
        'exampleTitle' => 'Install snippet example',
        'htmlTitle' => 'Plain HTML',
        'spaTitle' => 'React / Vue / SPA',
        'wpTitle' => 'WordPress',
        'htmlBody' => 'Place the tag in your main layout file before </head>.',
        'spaBody' => 'Place the tag in the app HTML entry file, such as index.html. Berack tracks SPA URL changes through pushState, replaceState, back, and forward navigation.',
        'wpBody' => 'If you edit the theme directly, add the tag to header.php before </head>. If you use a header scripts plugin, paste the snippet there.',
        'verifyTitle' => '4. Verify installation',
        'verifyBody' => 'After installing the tag, open your website and visit a few pages. Then return to Berack and check Analytics. If everything is correct, page_view events should appear.',
        'analyticsTitle' => '5. View analytics',
        'analyticsBody' => 'In the user panel, Analytics shows events for your websites. Each user only sees their own sites and analytics.',
        'analyticsItems' => [
            'Page URL and path',
            'Page title',
            'Referrer and previous URL',
            'Anonymous visitor ID and session ID',
            'Event timestamp',
            'Viewport and screen data in the payload',
        ],
        'troubleTitle' => 'Troubleshooting',
        'troubleItems' => [
            ['No analytics appear', 'Make sure the snippet was copied from the correct site panel and placed inside the page head.'],
            ['Wrong API key', 'Each site has its own API key. If you manage multiple sites, use each site snippet only for that site.'],
            ['My website is an SPA', 'No extra code is needed; the SDK tracks SPA URL changes automatically.'],
            ['Testing locally', 'The backend URL in the snippet must point to the domain where Laravel is running.'],
        ],
        'ctaTitle' => 'Ready to start?',
        'ctaLead' => 'Create an account, add your site, and install the Berack tag in a few minutes.',
    ];
@endphp

<!doctype html>
<html lang="{{ $lang }}" dir="{{ $dir }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Berack Guide</title>
    <meta name="description" content="A practical guide for installing the Berack tag and using the user panel.">
    <link href="{{ url('/assets/fonts/vazirmatn.css') }}" rel="stylesheet">
    <style>
        :root {
            --ink: #17211b;
            --muted: #64716a;
            --line: #dce5df;
            --paper: #fbfcf9;
            --panel: #ffffff;
            --green: #1f7a5b;
            --green-dark: #15533f;
            --blue: #3662a8;
        }

        * { box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body {
            margin: 0;
            background: var(--paper);
            color: var(--ink);
            font-family: "Vazirmatn", ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
            line-height: 1.8;
        }
        a { color: inherit; text-decoration: none; }
        code, pre { direction: ltr; text-align: left; }
        .shell { width: min(1060px, calc(100% - 32px)); margin-inline: auto; }
        .nav {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 20px;
            padding: 22px 0;
        }
        .brand { display: flex; align-items: center; gap: 10px; font-weight: 900; }
        .mark {
            display: grid;
            place-items: center;
            width: 34px;
            height: 34px;
            border-radius: 8px;
            background: var(--ink);
            color: #fff;
        }
        .nav-actions { display: flex; align-items: center; gap: 10px; flex-wrap: wrap; justify-content: flex-end; }
        .link { color: var(--muted); font-weight: 750; font-size: 14px; }
        .button {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-height: 42px;
            border-radius: 8px;
            padding: 0 16px;
            border: 1px solid var(--line);
            background: #fff;
            font-weight: 850;
        }
        .button.primary { border-color: var(--green); background: var(--green); color: #fff; }
        .hero { padding: 44px 0 52px; }
        .eyebrow {
            display: inline-flex;
            color: var(--green-dark);
            background: #e5f3ec;
            border: 1px solid #c6dfd2;
            padding: 7px 12px;
            border-radius: 999px;
            font-size: 13px;
            font-weight: 850;
        }
        h1 {
            margin: 18px 0 14px;
            max-width: 840px;
            font-size: clamp(34px, 5vw, 62px);
            line-height: 1.12;
            letter-spacing: 0;
        }
        .lead { max-width: 760px; color: var(--muted); font-size: 19px; }
        .toc {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 10px;
            margin-top: 30px;
        }
        .toc a {
            border: 1px solid var(--line);
            background: #fff;
            border-radius: 8px;
            padding: 13px 14px;
            color: var(--green-dark);
            font-weight: 850;
        }
        .section { padding: 42px 0; border-top: 1px solid var(--line); }
        .guide-grid {
            display: grid;
            grid-template-columns: 280px 1fr;
            gap: 28px;
            align-items: start;
        }
        .side-note {
            position: sticky;
            top: 18px;
            border: 1px solid var(--line);
            border-radius: 8px;
            background: #fff;
            padding: 18px;
        }
        .side-note strong { display: block; margin-bottom: 8px; }
        .side-note p { margin: 0; color: var(--muted); font-size: 14px; }
        .content { display: grid; gap: 18px; }
        .block {
            border: 1px solid var(--line);
            border-radius: 8px;
            background: var(--panel);
            padding: 24px;
        }
        h2 { margin: 0 0 10px; font-size: clamp(24px, 3vw, 34px); line-height: 1.2; letter-spacing: 0; }
        h3 { margin: 0 0 8px; font-size: 18px; }
        p { margin: 0; color: var(--muted); }
        pre {
            overflow-x: auto;
            margin: 16px 0 0;
            border-radius: 8px;
            background: #111b16;
            color: #e5f3ec;
            padding: 16px;
            font-size: 14px;
            line-height: 1.7;
        }
        .install-options {
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 12px;
            margin-top: 16px;
        }
        .mini {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 16px;
            background: #fbfdfb;
        }
        .checks {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 10px;
            margin-top: 16px;
        }
        .check {
            border: 1px solid var(--line);
            background: #fff;
            border-radius: 8px;
            padding: 12px 14px;
            font-weight: 800;
        }
        .trouble {
            display: grid;
            gap: 12px;
            margin-top: 16px;
        }
        .trouble-item {
            border: 1px solid var(--line);
            border-radius: 8px;
            padding: 16px;
            background: #fff;
        }
        .trouble-item strong { display: block; margin-bottom: 4px; }
        .cta {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 18px;
            align-items: center;
            border-radius: 8px;
            background: var(--ink);
            color: #fff;
            padding: 28px;
        }
        .cta p { color: #c7d2cc; }
        footer { color: var(--muted); padding: 28px 0 42px; font-size: 14px; }

        @media (max-width: 860px) {
            .toc, .install-options, .checks { grid-template-columns: 1fr; }
            .guide-grid, .cta { grid-template-columns: 1fr; }
            .side-note { position: static; }
        }
    </style>
</head>
<body>
    <header class="shell nav">
        <a class="brand" href="{{ $homeUrl }}" aria-label="Berack">
            <span class="mark">B</span>
            <span>Berack</span>
        </a>
        <nav class="nav-actions" aria-label="Primary">
            <a class="link" href="{{ $switchUrl }}">{{ $copy['switch'] }}</a>
            <a class="link" href="{{ $homeUrl }}">{{ $copy['back'] }}</a>
            <a class="link" href="{{ $loginUrl }}">{{ $copy['login'] }}</a>
            <a class="button primary" href="{{ $registerUrl }}">{{ $copy['register'] }}</a>
        </nav>
    </header>

    <main>
        <section class="shell hero">
            <span class="eyebrow">{{ $copy['eyebrow'] }}</span>
            <h1>{{ $copy['title'] }}</h1>
            <p class="lead">{{ $copy['lead'] }}</p>
            <div class="toc" aria-label="{{ $copy['tocTitle'] }}">
                @foreach ($copy['sections'] as [$id, $label])
                    <a href="#{{ $id }}">{{ $label }}</a>
                @endforeach
            </div>
        </section>

        <section class="section">
            <div class="shell guide-grid">
                <aside class="side-note">
                    <strong>{{ $copy['tocTitle'] }}</strong>
                    <p>{{ $copy['lead'] }}</p>
                </aside>

                <div class="content">
                    <article class="block" id="account">
                        <h2>{{ $copy['accountTitle'] }}</h2>
                        <p>{{ $copy['accountBody'] }}</p>
                        <pre><code>{{ $registerUrl }}</code></pre>
                    </article>

                    <article class="block" id="site">
                        <h2>{{ $copy['siteTitle'] }}</h2>
                        <p>{{ $copy['siteBody'] }}</p>
                    </article>

                    <article class="block" id="tag">
                        <h2>{{ $copy['tagTitle'] }}</h2>
                        <p>{{ $copy['tagBody'] }}</p>
                        <pre><code>&lt;script async src="{{ url('/sdk/trk_your_site_api_key.js') }}"&gt;&lt;/script&gt;</code></pre>
                        <div class="install-options">
                            <div class="mini">
                                <h3>{{ $copy['htmlTitle'] }}</h3>
                                <p>{{ $copy['htmlBody'] }}</p>
                            </div>
                            <div class="mini">
                                <h3>{{ $copy['spaTitle'] }}</h3>
                                <p>{{ $copy['spaBody'] }}</p>
                            </div>
                            <div class="mini">
                                <h3>{{ $copy['wpTitle'] }}</h3>
                                <p>{{ $copy['wpBody'] }}</p>
                            </div>
                        </div>
                    </article>

                    <article class="block" id="verify">
                        <h2>{{ $copy['verifyTitle'] }}</h2>
                        <p>{{ $copy['verifyBody'] }}</p>
                    </article>

                    <article class="block" id="analytics">
                        <h2>{{ $copy['analyticsTitle'] }}</h2>
                        <p>{{ $copy['analyticsBody'] }}</p>
                        <div class="checks">
                            @foreach ($copy['analyticsItems'] as $item)
                                <div class="check">{{ $item }}</div>
                            @endforeach
                        </div>
                    </article>

                    <article class="block" id="troubleshooting">
                        <h2>{{ $copy['troubleTitle'] }}</h2>
                        <div class="trouble">
                            @foreach ($copy['troubleItems'] as [$title, $body])
                                <div class="trouble-item">
                                    <strong>{{ $title }}</strong>
                                    <p>{{ $body }}</p>
                                </div>
                            @endforeach
                        </div>
                    </article>

                    <section class="cta">
                        <div>
                            <h2>{{ $copy['ctaTitle'] }}</h2>
                            <p>{{ $copy['ctaLead'] }}</p>
                        </div>
                        <a class="button primary" href="{{ $registerUrl }}">{{ $copy['register'] }}</a>
                    </section>
                </div>
            </div>
        </section>
    </main>

    <footer class="shell">
        Berack · Guide
    </footer>
</body>
</html>
