@php
    $site = $this->getRecord();
    $stats = $this->getReportStats();
    $dailyViews = $this->getDailyViews();
    $topPages = $this->getTopPages();
    $topReferrers = $this->getTopReferrers();
    $recentVisits = $this->getRecentVisits();
    $maxDailyViews = max(1, ...array_column($dailyViews, 'views'));
@endphp

<x-filament-panels::page>
    <div class="space-y-6">
        <section class="fi-section rounded-lg border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
            <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                <div>
                    <h2 class="text-lg font-bold text-gray-950 dark:text-white">{{ $site->name }}</h2>
                    <p class="text-sm text-gray-500 dark:text-gray-400">{{ $site->domain ?: $this->t('دامنه ثبت نشده', 'No domain set') }}</p>
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                    {{ $this->t('آخرین بازدید:', 'Last visit:') }}
                    <span class="font-medium text-gray-800 dark:text-gray-200">
                        {{ $stats['lastSeenAt'] ? \Illuminate\Support\Carbon::parse($stats['lastSeenAt'])->format('Y-m-d H:i') : '-' }}
                    </span>
                </div>
            </div>
        </section>

        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
            <div class="fi-section rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $this->t('کل بازدیدها', 'Total views') }}</div>
                <div class="mt-2 text-2xl font-bold text-primary-700 dark:text-primary-300">{{ number_format($stats['total']) }}</div>
            </div>
            <div class="fi-section rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $this->t('امروز', 'Today') }}</div>
                <div class="mt-2 text-2xl font-bold text-primary-700 dark:text-primary-300">{{ number_format($stats['today']) }}</div>
                <div class="mt-1 text-xs text-gray-500 dark:text-gray-400">{{ $stats['yesterdayDelta'] }} {{ $this->t('نسبت به دیروز', 'vs yesterday') }}</div>
            </div>
            <div class="fi-section rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $this->t('بازدیدکننده یکتا', 'Unique visitors') }}</div>
                <div class="mt-2 text-2xl font-bold text-primary-700 dark:text-primary-300">{{ number_format($stats['visitors']) }}</div>
            </div>
            <div class="fi-section rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $this->t('نشست‌ها', 'Sessions') }}</div>
                <div class="mt-2 text-2xl font-bold text-primary-700 dark:text-primary-300">{{ number_format($stats['sessions']) }}</div>
            </div>
            <div class="fi-section rounded-lg border border-gray-200 bg-white p-4 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <div class="text-sm text-gray-500 dark:text-gray-400">{{ $this->t('صفحه‌ها', 'Pages') }}</div>
                <div class="mt-2 text-2xl font-bold text-primary-700 dark:text-primary-300">{{ number_format($stats['pages']) }}</div>
            </div>
        </div>

        <section class="fi-section rounded-lg border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
            <h3 class="text-base font-bold text-gray-950 dark:text-white">{{ $this->t('روند ۱۴ روز اخیر', 'Last 14 days') }}</h3>
            <div class="mt-5 flex h-56 items-end gap-2">
                @foreach ($dailyViews as $day)
                    <div class="flex min-w-0 flex-1 flex-col items-center gap-2">
                        <div class="w-full rounded-t bg-primary-500/80 dark:bg-primary-400" style="height: {{ max(4, ($day['views'] / $maxDailyViews) * 190) }}px"></div>
                        <div class="truncate text-xs text-gray-500 dark:text-gray-400">{{ $day['label'] }}</div>
                    </div>
                @endforeach
            </div>
        </section>

        <div class="grid gap-6 xl:grid-cols-2">
            <section class="fi-section rounded-lg border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <h3 class="text-base font-bold text-gray-950 dark:text-white">{{ $this->t('صفحه‌های پربازدید', 'Top pages') }}</h3>
                <div class="mt-4 overflow-x-auto">
                    <table class="w-full text-sm">
                        <thead class="text-left text-gray-500 dark:text-gray-400">
                            <tr>
                                <th class="py-2 font-medium">{{ $this->t('مسیر', 'Path') }}</th>
                                <th class="py-2 font-medium">{{ $this->t('بازدید', 'Views') }}</th>
                                <th class="py-2 font-medium">{{ $this->t('بازدیدکننده', 'Visitors') }}</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-100 dark:divide-gray-800">
                            @forelse ($topPages as $page)
                                <tr>
                                    <td class="py-3">
                                        <div class="font-medium text-gray-900 dark:text-gray-100">{{ $page['path'] }}</div>
                                        <div class="text-xs text-gray-500 dark:text-gray-400">{{ $page['title'] ?: '-' }}</div>
                                    </td>
                                    <td class="py-3 text-gray-700 dark:text-gray-300">{{ number_format($page['views']) }}</td>
                                    <td class="py-3 text-gray-700 dark:text-gray-300">{{ number_format($page['visitors']) }}</td>
                                </tr>
                            @empty
                                <tr><td colspan="3" class="py-6 text-center text-gray-500">{{ $this->t('هنوز داده‌ای ثبت نشده است.', 'No data yet.') }}</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </section>

            <section class="fi-section rounded-lg border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
                <h3 class="text-base font-bold text-gray-950 dark:text-white">{{ $this->t('منابع ورودی', 'Top referrers') }}</h3>
                <div class="mt-4 space-y-3">
                    @forelse ($topReferrers as $referrer)
                        <div class="flex items-center justify-between gap-4 rounded-lg bg-gray-50 px-3 py-2 dark:bg-gray-800">
                            <div class="min-w-0 truncate text-sm text-gray-800 dark:text-gray-200">{{ $referrer['referrer'] }}</div>
                            <div class="shrink-0 text-sm font-semibold text-primary-700 dark:text-primary-300">{{ number_format($referrer['views']) }}</div>
                        </div>
                    @empty
                        <div class="py-6 text-center text-sm text-gray-500">{{ $this->t('هنوز منبع ورودی ثبت نشده است.', 'No referrers yet.') }}</div>
                    @endforelse
                </div>
            </section>
        </div>

        <section class="fi-section rounded-lg border border-gray-200 bg-white p-5 shadow-sm dark:border-gray-800 dark:bg-gray-900">
            <h3 class="text-base font-bold text-gray-950 dark:text-white">{{ $this->t('آخرین بازدیدها', 'Recent visits') }}</h3>
            <div class="mt-4 overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="text-left text-gray-500 dark:text-gray-400">
                        <tr>
                            <th class="py-2 font-medium">{{ $this->t('زمان', 'Time') }}</th>
                            <th class="py-2 font-medium">{{ $this->t('مسیر', 'Path') }}</th>
                            <th class="py-2 font-medium">{{ $this->t('عنوان', 'Title') }}</th>
                            <th class="py-2 font-medium">{{ $this->t('ارجاع‌دهنده', 'Referrer') }}</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-gray-100 dark:divide-gray-800">
                        @forelse ($recentVisits as $visit)
                            <tr>
                                <td class="py-3 text-gray-700 dark:text-gray-300">{{ $visit['occurred_at'] }}</td>
                                <td class="py-3 font-medium text-gray-900 dark:text-gray-100">{{ $visit['path'] ?: '-' }}</td>
                                <td class="py-3 text-gray-700 dark:text-gray-300">{{ $visit['title'] ?: '-' }}</td>
                                <td class="py-3 text-gray-700 dark:text-gray-300">{{ $visit['referrer'] ?: $this->t('مستقیم', 'Direct') }}</td>
                            </tr>
                        @empty
                            <tr><td colspan="4" class="py-6 text-center text-gray-500">{{ $this->t('هنوز بازدیدی ثبت نشده است.', 'No visits yet.') }}</td></tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </section>
    </div>
</x-filament-panels::page>
